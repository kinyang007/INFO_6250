create procedure randomUserAndReview()
begin
  declare num int;
  declare review_cnt int;

  delete from user;
  delete from elite;
  delete from review;

  set num = 0;
  while num < 10 do
    set review_cnt = floor(1 + rand() * 9);
    insert into user (user_name, email, password, review_count, yelping_since, useful, funny, cool, fans, average_stars)
    values (concat('Username', num), concat('Email', num, '@yelp.com'), '123456', review_cnt, now(), 0, 0, 0, 0, 0);

    set @tmp = 0;
    while @tmp < floor(0 + rand() * 2) do
      set @userId = (select user_id from user where user_name = concat('Username', num));
      insert into elite values (@userId, floor(2010 + rand() * 9));
      set @tmp = @tmp + 1;
    end while;

    set @tmp = 0;
    set @total_star = 0.0;
    while @tmp < review_cnt do
      set @userId = (select user_id from user where user_name = concat('Username', num));
      set @businessId = (select business_id from business order by rand() limit 1);
      set @star = floor(1 + rand() * 4);
      set @total_star = @total_star + @star;
      insert into review (user_id, business_id, stars, date, text, useful, funny, cool)
      values (@userId, @businessId, @star, now(), concat('Review Text', @tmp), 0, 0, 0);
      update business set review_count = review_count + 1, stars = (stars * review_count + @star) / (review_count + 1) where business_id = @businessId;
      set @tmp = @tmp + 1;
    end while;
    update user set average_stars = @total_star / review_count where user_name = concat('Username', num);
    set num = num + 1;
  end while;
end;

