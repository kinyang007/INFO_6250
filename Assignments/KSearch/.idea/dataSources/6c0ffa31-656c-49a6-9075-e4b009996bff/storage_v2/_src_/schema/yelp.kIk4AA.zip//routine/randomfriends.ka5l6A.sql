create procedure randomFriends()
  begin
  declare num int;
  delete from friends;
  set num = 0;
  while num < 500 do
    set @user_id1 = (select user_id from user order by rand() limit 1);
    set @user_id2 = (select user_id from user order by rand() limit 1);
    set @cnt = (select count(*) from friends where user_id = @user_id1 and friend_id = @user_id2);
    if @user_id1 != @user_id2 and @cnt = 0 then
      insert into friends values (@user_id1, @user_id2);
    end if;
    set num = num + 1;
  end while;
end;

