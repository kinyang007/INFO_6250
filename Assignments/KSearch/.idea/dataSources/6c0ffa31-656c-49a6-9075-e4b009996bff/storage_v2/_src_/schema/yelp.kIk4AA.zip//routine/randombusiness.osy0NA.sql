create procedure randomBusiness()
  begin
	declare num int;
  declare tmp varchar(255);
  set num = 0;

  delete from business;
  delete from attributes;
  delete from hours;
  delete from category;

  while num < 100 do
		insert into yelp.business (business_name, address, city, state, postal_code, latitude, longitude, stars, review_count, is_open)
		values (concat('Business Test', num), concat('Address Test', num), concat('City Test', num), concat('State Test', num), '123456', 100, 100, 0, 0, 1);
		set @business_id = (select business_id from business where business_name = concat('Business Test', num));
		insert into yelp.hours (business_id, day, start_time, close_time) values (@business_id, 'Monday', '9:00', '21:00');
		insert into yelp.hours (business_id, day, start_time, close_time) values (@business_id, 'Tuesday', '9:00', '21:00');
		insert into yelp.hours (business_id, day, start_time, close_time) values (@business_id, 'Wednesday', '9:00', '21:00');
		insert into yelp.hours (business_id, day, start_time, close_time) values (@business_id, 'Thursday', '9:00', '21:00');
		insert into yelp.hours (business_id, day, start_time, close_time) values (@business_id, 'Friday', '9:00', '21:00');
		insert into yelp.hours (business_id, day, start_time, close_time) values (@business_id, 'Saturday', '8:00', '22:00');
		insert into yelp.hours (business_id, day, start_time, close_time) values (@business_id, 'Sunday', '8:00', '22:00');
		insert into yelp.category values (@business_id, 'Test1');
		insert into yelp.category values (@business_id, 'Test2');
		insert into yelp.category values (@business_id, 'Test3');
		insert into yelp.attributes (business_id, name, value) values (@business_id, 'Name1', 'Value1');
		insert into yelp.attributes (business_id, name, value) values (@business_id, 'Name2', 'Value2');
		insert into yelp.attributes (business_id, name, value) values (@business_id, 'Name3', 'Value3');
    set num = num + 1;
	end while;
end;

